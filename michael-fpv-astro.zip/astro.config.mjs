// @ts-check
import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';

// NOTE: `site` and `base` must match where the site is actually hosted.
// Current setup = GitHub project page at /Michael-FPV/
//
// If you later move to a custom domain (e.g. michaelfpv.com), change to:
//   site: 'https://michaelfpv.com',
//   base: '/',
export default defineConfig({
  site: 'https://michaelsfpv-ctrl.github.io',
  base: '/Michael-FPV',
  trailingSlash: 'always',
  integrations: [sitemap()],
  build: { inlineStylesheets: 'auto' },
});
